//
//  MorphingButton.swift
//  SportsDB
//
//  Created by Macbook on 6/8/25.
//

import SwiftUI

struct MorphingButton<Label: View, Content: View, ExpandedContent: View>: View {
    var backgroundColor: Color
    @Binding var showExpandedContent: Bool
    @Binding var showFullScreenCover: Bool
    @ViewBuilder var label: Label
    @ViewBuilder var content: Content
    @ViewBuilder var expandedContent: ExpandedContent

    // View Properties
    
    @State private var animateContent: Bool = false
    @State private var viewPosition: CGRect = .zero

    var body: some View {
        label
            .onGeometryChange(for: CGRect.self, of: {
                $0.frame(in: .global)
            }, action: { newValue in
                viewPosition = newValue
            })
            .opacity(showFullScreenCover ? 0 : 1)
            .padding(.trailing, 5)
            .padding(.bottom, 5)
            .onTapGesture {
                toggleFullScreenCover(false, status: true)
            }
            .fullScreenCover(isPresented: $showFullScreenCover) {
                ZStack(alignment: .topLeading) {
                    if animateContent {
                        ZStack(alignment: .top) {
                            if showExpandedContent {
                                expandedContent
                                    .transition(.blurReplace)
                            } else {
                                content
                                    .transition(.blurReplace)
                            }
                        }
                        .transition(.blurReplace)
                    } else {
                        label
                            .transition(.blurReplace)
                    }
                }
                .geometryGroup()
                .clipShape(.rect(cornerRadius: 30, style: .continuous))
                .padding(.horizontal, animateContent && !showExpandedContent ? 15 : 0)
                .padding(.bottom, animateContent && !showExpandedContent ? 5 : 0)
                .frame(maxWidth: .infinity, maxHeight: .infinity
                    , alignment: animateContent ? .bottom : .topLeading)
                .offset(x: animateContent ? 0 : viewPosition.minX,
                        y: animateContent ? 0 : viewPosition.minY
                )
                .ignoresSafeArea(animateContent ? [] : .all)
                .background {
                    Rectangle()
                        .fill(.black.opacity(animateContent ? 0.01 : 0))
                        .background(.ultraThinMaterial.opacity(0.3))
                        .ignoresSafeArea()
                        .onTapGesture(perform: closeView)
                        //.onTapGesture { closeView() }
                }
                .task {
                    try? await Task.sleep(for: .seconds(0.05))
                    withAnimation(.interpolatingSpring(duration: 0.2, bounce: 0)) {
                        animateContent = true
                    }
                }
                .animation(.interpolatingSpring(duration: 0.2, bounce: 0), value: showExpandedContent)
                .presentationBackground(.clear)
            }
    }

    private func toggleFullScreenCover(_ withAnimation: Bool, status: Bool) {
        var transaction = Transaction()
        transaction.disablesAnimations = !withAnimation

        withTransaction(transaction) {
            showFullScreenCover = status
        }
    }
    
    func closeView() {
        withAnimation(.interpolatingSpring(duration: 0.2, bounce: 0),
                      completionCriteria: .removed) {
            animateContent = false
        } completion: {
            /// Removing Sheet After a little delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                toggleFullScreenCover(false, status: false)
            }
        }
    }
}
