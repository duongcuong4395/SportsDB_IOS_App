//
//  VenueEndpoint.swift
//  SportsDB
//
//  Created by Macbook on 28/5/25.
//

enum VenueEndpoint<T: Decodable> {
    case LookupVenue(eventID: String)
    case SearchVenues(venueName: String)
}

import Foundation
import Alamofire
import Networking

extension VenueEndpoint: HttpRouter {
    typealias ResponseType = T
    
    var method: Alamofire.HTTPMethod {
        .get
    }
    
    //typealias responseDataType = T
    
    var baseURL: String {
        AppUtility.SportBaseURL
    }
    
    var path: String {
        switch self {
        case .LookupVenue(eventID: _):
            return "api/v1/json/123/lookupvenue.php"
        case .SearchVenues(venueName: _):
            return "api/v1/json/3/searchvenues.php"
        }
    }
    
    var headers: Alamofire.HTTPHeaders? {
        nil
    }
    
    var parameters: Alamofire.Parameters? {
        switch self {
        case .LookupVenue(eventID: let eventID):
            return ["id": eventID]
        case .SearchVenues(venueName: let venueName):
            return ["v": venueName]
            
        }
    }
    
    var body: Data? {
        nil
    }
    
    
}
