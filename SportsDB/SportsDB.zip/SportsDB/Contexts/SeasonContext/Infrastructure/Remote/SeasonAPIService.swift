//
//  SeasonAPIService.swift
//  SportsDB
//
//  Created by Macbook on 29/5/25.
//

import Networking

class SeasonAPIService: APIExecution, SeasonRepository {
    func getListSeasons(leagueID: String) async throws -> [Season] {
        let response: GetListSeasonsAPIResponse = try await sendRequest(for: SeasonEndpoint<GetListSeasonsAPIResponse>.GetListSeasons(leagueID: leagueID))
        
        return response.seasons.map { $0.toDomain() }
    }
    
    
}
